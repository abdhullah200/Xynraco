<script>
	import './styles.css';
</script>

<div class="app">
	<main>
		<slot />
	</main>
</div>
