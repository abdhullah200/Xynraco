# JSON Server starter

1. Run `npm run backend` in the terminal to start the server.
2. Open a second terminal (by clicking the `[+]` icon) and run `npm run frontend` to open a simple page that fetches data from our backend