import './App.css';

function App() {
  return (
    <>
      <div>Start prompting.</div>
    </>
  );
}

export default App;
