console.log(`
  Your random number is: ${Math.random()}
  (edit any file to auto-restart this script)
`);
