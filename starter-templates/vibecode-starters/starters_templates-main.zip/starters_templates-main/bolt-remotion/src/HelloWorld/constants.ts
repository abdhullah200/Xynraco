// change any of these to update your video live

export const COLOR_1 = "#86A8E7";

export const FONT_FAMILY = "SF Pro Text, Helvetica, Arial, sans-serif";
