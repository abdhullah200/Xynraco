exports.security = {
  xframe: {
    enable: false,
  },
};
