<script setup lang="ts">
import TheExperience from './components/TheExperience.vue'
</script>

<template>
  <TheExperience />
</template>
